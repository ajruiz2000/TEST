#define kmsec 			313
#define ksec 			313000
#define kNesLabsDIO 	BIT_1
#define kAthenaDIO 		BIT_2
#define kPowerDIO		BIT_3

//#include "GenericTypeDefs.h"

void Wait(int);
void ShutDown1(void);


float newTemp;


