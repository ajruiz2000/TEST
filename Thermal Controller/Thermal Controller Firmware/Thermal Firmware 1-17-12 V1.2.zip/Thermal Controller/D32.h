
#ifndef D32_H
#define D32_H

extern void UserInit(void);
extern void ProcessIO(void);

#endif

